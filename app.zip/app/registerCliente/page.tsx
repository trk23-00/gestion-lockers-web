"use client";

import RegisterClientForm from "@/components/inicio_sesion/RegisterClientForm";

export default function RegisterClientePage() {
  return (
    <main className="authPage">
      <RegisterClientForm/>
    </main>
  );
}