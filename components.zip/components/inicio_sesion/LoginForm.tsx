"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import styles from "@/components/inicio_sesion/LoginForm.module.css"
import AuthButton from "./AuthButton";
import AuthLayout from "./AuthLayout";
import Logo from "./Logo"

const LoginForm = () => {

  const router = useRouter();

  const [correo, setCorreo] = useState("");
  const [password, setPassword] = useState("");

  const [errorMessage, setErrorMessage] =
    useState("");

  const [successMessage, setSuccessMessage] =
    useState("");

  async function login() {

    if(!correo || !password){

      setErrorMessage(
        "Debe llenar todos los campos"
      );

      setSuccessMessage("");

      return;

    }

    try {

      const response = await fetch(
        "/api/auth/login",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            correo,
            password,
          }),
        }
      );

      const data = await response.json();

      if(!response.ok){

        setErrorMessage(data.message);

        setSuccessMessage("");

        return;

      }

      setErrorMessage("");

      setSuccessMessage(
        "Inicio de sesión exitoso"
      );

      router.refresh();

      router.push("/dashboard");

    } catch(error){

      console.log(error);

      setErrorMessage(
        "Error al conectar con el servidor"
      );

      setSuccessMessage("");

    }

  }

  return (
      <AuthLayout title="INICIAR SESIÓN">
        <div className={styles.inputGroup}>

          <label className={styles.label}>
            Carnet de Identidad
          </label>

          <input
            type="email"
            placeholder="Ingresa tu número de CI"
            value={correo}
            onChange={(e)=>setCorreo(e.target.value)}
          />

        </div>

        <div className={styles.inputGroup}>

          <label className={styles.label}>
            Contraseña
          </label>

          <input
            type="password"
            placeholder="Ingresa tu contraseña"
            value={password}
            onChange={(e)=>setPassword(e.target.value)}
          />

        </div>

        {
          errorMessage && (
            <p className={styles.errorText}>
              {errorMessage}
            </p>
          )
        }

        {
          successMessage && (
            <p className={styles.successText}>
              {successMessage}
            </p>
          )
        }
        <p className={styles.olvideContraseña}>
          Olvidaste tu contraseña?
          <Link
            className={styles.forgotPassword}
            href="/password"
            >
            Recuperar contraseña
          </Link>
        </p>

        <AuthButton
          text="Iniciar Sesión"
          onClick={login}
        />

      </AuthLayout>
  );

};

export default LoginForm;