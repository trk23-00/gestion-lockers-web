import styles from "@/components/inicio_sesion/RegisterClientForm.module.css"

const RegisterClientForm = () => {
  return (
    <div>RegisterClientForm</div>
  )
}

export default RegisterClientForm