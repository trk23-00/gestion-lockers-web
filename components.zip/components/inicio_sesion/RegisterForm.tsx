"use client";

import { useState } from "react";
import Link from "next/link";
import styles from "@/components/inicio_sesion/RegisterForm.module.css"
import AuthButton from "./AuthButton";
import AuthLayout from "./AuthLayout";

const RegisterForm = () => {
  const [nombre, setNombre] = useState("");
  const [correo, setCorreo] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const passwordsMatch = password === confirmPassword;
  async function register() {
    // =========================
    // VALIDACIONES FRONTEND
    // =========================
    if (
      !nombre ||
      !correo ||
      !password ||
      !confirmPassword
    ) {
      setErrorMessage("Debe llenar todos los campos");
      setSuccessMessage("");
      return;
    }
    if (!passwordsMatch) {
      setErrorMessage("Las contraseñas no coinciden");
      setSuccessMessage("");
      return;
    }
    try {
      // =========================
      // FETCH BACKEND
      // =========================
      const response = await fetch(
        "/api/auth/register",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            nombre,
            correo,
            password,
          }),
        }
      );
      const data = await response.json();
      // =========================
      // SI EL BACKEND FALLA
      // =========================
      if (!response.ok) {
        setErrorMessage(data.message);
        setSuccessMessage("");
        return;
      }
      // =========================
      // REGISTRO EXITOSO
      // =========================
      setErrorMessage("");
      setSuccessMessage(
        "Cuenta registrada correctamente"
      );
      console.log(data);
      // limpiar inputs
      setNombre("");
      setCorreo("");
      setPassword("");
      setConfirmPassword("");

    } catch (error) {
      console.log(error);
      setErrorMessage(
        "Error al conectar con el servidor"
      );
      setSuccessMessage("");
    }
  }

  return (
    <AuthLayout title={`CREAR CUENTA DE EMPLEADO`}>
      <div className={styles.inputGroup}>
        <label className={styles.label}>
          Nombre
        </label>
        <input
          type="text"
          placeholder="Ingresa nombre del empleado"
          value={nombre}
          onChange={(e)=>setNombre(e.target.value)}
        />
      </div>
      <div className={styles.inputGroup}>
        <label className={styles.label}>
          Apellidos
        </label>
        <input
          type="text"
          placeholder="Ingresa los apellidos del empleado"
          value={nombre}
          onChange={(e)=>setNombre(e.target.value)}
        />
      </div>
      <div className={styles.inputGroup}>
        <label className={styles.label}>
          Carnet de Identidad
        </label>
        <input
          type="text"
          placeholder="Ingresa el número de CI del empleado"
          value={correo}
          onChange={(e)=>setCorreo(e.target.value)}
        />
      </div>
      <div className={styles.inputGroup}>
        <label className={styles.label}>
          Correo Electrónico
        </label>
        <input
          type="text"
          placeholder="Ingresa el correo electrónico del empleado"
          value={correo}
          onChange={(e)=>setCorreo(e.target.value)}
        />
      </div>
      <div className={styles.inputGroup}>
        <label className={styles.label}>
          Cargo
        </label>
        <select name="cargo">
          <option value="Recepcionista">Recepcionista</option>
          <option value="Almacenero">Almacenero</option>
        </select>
      </div>
      <div className={styles.inputGroup}>
        <label className={styles.label}>
          Contraseña
        </label>
        <input
          type="password"
          placeholder="Ingresa una contraseña para el empleado"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      {
        errorMessage && (
          <p className={styles.errorText}>
            {errorMessage}
          </p>
        )
      }
      {
        successMessage && (
          <p className={styles.successText}>
            {successMessage}
          </p>
        )
      }
      <AuthButton
        text="Registrarse"
        onClick={register}
      />
    </AuthLayout>
  );
};

export default RegisterForm;