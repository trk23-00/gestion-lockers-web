"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import styles from "@/components/inicio_sesion/LoginForm.module.css";
import AuthButton from "./AuthButton";
import AuthLayout from "./AuthLayout";
import Captcha from "./Captcha";
import { postJson } from "@/lib/api";
import { rutaPanel } from "@/lib/paneles";

const LoginForm = () => {
  const router = useRouter();

  const [correo, setCorreo] = useState("");
  const [password, setPassword] = useState("");
  const [captchaToken, setCaptchaToken] = useState<string | null>(null);
  const [captchaKey, setCaptchaKey] = useState(0);
  const [errorMessage, setErrorMessage] = useState("");
  const [cargando, setCargando] = useState(false);

  function refrescarCaptcha() {
    setCaptchaToken(null);
    setCaptchaKey((key) => key + 1);
  }

  async function login() {
    if (!correo.trim() || !password) {
      setErrorMessage("Debe llenar todos los campos");
      return;
    }

    if (!captchaToken) {
      setErrorMessage("Debe completar el captcha");
      return;
    }

    setErrorMessage("");
    setCargando(true);

    const respuesta = await postJson<{ usuario: { nivel: number } }>("/api/auth/login", {
      correo,
      password,
      captcha: captchaToken,
    });

    setCargando(false);

    if (!respuesta.ok) {
      setErrorMessage(respuesta.message);
      refrescarCaptcha();
      return;
    }

    router.push(rutaPanel(respuesta.data?.usuario.nivel ?? 0));
    router.refresh();
  }

  return (
    <AuthLayout title="INICIAR SESIÓN" onSubmit={login}>
      <p className={styles.intro}>¡Bienvenido de nuevo!</p>
      <div className={styles.inputGroup}>
        <label className={styles.label} htmlFor="correo">Correo Electrónico</label>
        <input id="correo" type="email" placeholder="ejemplo@ejemplo.com" autoComplete="email" value={correo} onChange={(e) => setCorreo(e.target.value)} />
      </div>
      <div className={styles.inputGroup}>
        <label className={styles.label} htmlFor="password">Contraseña</label>
        <input id="password" type="password" placeholder="••••••••••••" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
      </div>
      <p className={styles.textoEnlace}><span>¿Olvidaste tu contraseña?</span><Link className={styles.enlace} href="/password">Recuperar Contraseña</Link></p>
      <Captcha onChange={setCaptchaToken} refreshKey={captchaKey} />
      {errorMessage && <p role="alert" className={styles.errorText}>{errorMessage}</p>}
      <AuthButton text="Iniciar Sesión" type="submit" disabled={cargando} />
    </AuthLayout>
  );
};
export default LoginForm;
